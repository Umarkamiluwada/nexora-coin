NEXORA COIN MINI APP — STARTER

This is the first frontend version for Nexora Coin (NXR).
It contains:
- Home dashboard
- NXR balance display
- Mining button
- Mining rate: 0.00000579 NXR/s
- 24-hour mining timer
- Telegram Mini App user greeting
- Placeholder buttons for Tasks, Referrals, Daily Reward and Leaderboard

IMPORTANT:
This version is a frontend prototype. Real balances, referrals, tasks, anti-cheat,
wallet withdrawals and a database/backend will be added in later steps.

DEPLOYMENT:
1. Create a GitHub repository.
2. Upload index.html, style.css and app.js to the repository root.
3. Enable GitHub Pages from Settings > Pages.
4. Choose Deploy from a branch, then main / root.
5. Open the published HTTPS address.
6. Use that HTTPS address in BotFather when it asks for the Web App URL.

Do NOT put a Telegram bot token in these files.
